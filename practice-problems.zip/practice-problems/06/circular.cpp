/* TODO: write a function that takes a string s and an integer n and circularly
 * shifts the string's characters to the right by n positions.  For example,
 * the string "Halloween" shifted by 3 would become "eenHallow".
 * NOTE: you can assume the integer is non-negative.
 * */

#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <string>
using std::string;

/* your answer goes here... */

int main()
{
	/* TODO: call your function, make sure it works... */
	return 0;
}

// vim:foldlevel=2
