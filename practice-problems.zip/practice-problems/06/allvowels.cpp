/* TODO: Write a function that takes a string parameter, and returns a boolean
 * value indicating whether or not *all* vowels (a,e,i,o,u) are present
 * somewhere in the string.  For example, if the input is "hello world", the
 * return value should be false, and on input "programming is super fun!" the
 * return value should be true.
 * NOTE: to simplify things, you can assume the input string is all lower case.
 * */

#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <string>
using std::string;

/* your answer goes here... */

int main()
{
	/* TODO: call your function, make sure it works... */
	return 0;
}

// vim:foldlevel=2
