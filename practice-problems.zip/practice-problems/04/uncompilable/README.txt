The exercises in this directory are a bit more abstract and contemplative.
The files here won't compile (hence no Makefile here).
