/* TODO: fix all compiler errors in the following program (you can of course
 * use the compiler to check your work...) */
#include <iostream>
using namespace std;

int main()
{
	cout << "hello world." << "\n";
	return 0;
}

// vim:foldlevel=2
