/* TODO: Try to write merge sort!  Prototypes are given below using vectors,
 * but if you would prefer, arrays are fine too. */

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <vector>
using std::vector;

/* This should take two SORTED vectors, L and R, and return another vector
 * which is sorted and contains all values from L and R. */
vector<int> merge(const vector<int>& L, const vector<int>& R);

void mergeSort(vector<int>& V);

int main()
{
	/* TODO: write some code here in main to test your function. */
	return 0;
}

// vim:foldlevel=2
