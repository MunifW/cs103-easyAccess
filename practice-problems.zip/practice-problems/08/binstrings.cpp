/* TODO: write a function (recursion isn't a bad idea) which takes an integer
 * n and returns a vector of all binary strings of length n.
 * E.g., if n = 3, output vector should contain the following strings:
 * 000
 * 001
 * 010
 * 011
 * 100
 * 101
 * 110
 * 111
 * */

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <vector>
using std::vector;
#include <string>
using std::string;

int main()
{
	/* TODO: write some test code here */
	return 0;
}

// vim:foldlevel=2
